package com.diya.apps.khatuni.activities.apps.model

/**
 * Created by Andrey Berezhnoi on 12.08.2019.
 * Copyright (c) 2019 mova.io. All rights reserved.
 */


class App(val title: String, val description: String, val image: Int, val link: String)