package com.diya.apps.khatuni;

public class Constants {

    public static final String SHER_PREF = "MY_PREFS";
    public static final String SECOND_START = "SECOND_START";

}